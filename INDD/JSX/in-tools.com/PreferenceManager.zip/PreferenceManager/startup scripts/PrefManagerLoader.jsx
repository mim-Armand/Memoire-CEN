
#targetengine "Prefs Manager"
var DEBUG = false ;
function assert( condition, text ) {
	if ( DEBUG && !condition ) { alert( text ) ; }
}
if (typeof(PrefManagerMenuItem) == 'undefined'){
	function PrefManagerMenuItemLoader(){}

	PrefManagerMenuItemLoader.getScriptsFolderPath = function(){
		try{var script = app.activeScript;}
		catch(e){var script = File(e.fileName);}
		return script.parent.parent ;	//this file is in the "startup scripts" subfolder
	}
	PrefManagerMenuItemLoader.loadScript = function(filename){
		return File(PrefManagerMenuItemLoader.getScriptsFolderPath() + '/' + filename );
	}

	PrefManagerMenuItemLoader.script = PrefManagerMenuItemLoader.loadScript('PrefManagerMenuItem.jsxbin');
	if ( !PrefManagerMenuItemLoader.script.exists ){
		PrefManagerMenuItemLoader.script = PrefManagerMenuItemLoader.loadScript('PrefManagerMenuItem.jsx');
	}
	assert( PrefManagerMenuItemLoader.script.exists, "PrefManagerMenuItem.jsx* missing; load failed" ) ;
	if ( PrefManagerMenuItemLoader.script.exists )
	{
		var cacheCurrent = Folder.current ;
		try{
			Folder.current = PrefManagerMenuItemLoader.getScriptsFolderPath();
			app.doScript(PrefManagerMenuItemLoader.script);
		}
		finally{Folder.current = cacheCurrent ;}
	}
}
