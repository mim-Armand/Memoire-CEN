﻿#target indesign;

try{
	SetGrep ("\\d+", {CS: app.activeDocument.footnoteOptions.footnoteMarkerStyle});
	var noterefs = app.activeDocument.findGrep();
	for (var n = noterefs.length-1; n >= 0; n--)
		noterefs[n].contents = String(n+1);
	SetGrep ("^.", {PS: app.activeDocument.footnoteOptions.footnoteTextStyle, FN: true});
	var notes = app.activeDocument.findGrep();
	if (noterefs.length != notes.length)
		alert ("Footnote numbers do not match footnote references.\r("+notes.length+" footnotes, "+noterefs.length+" references.)");
	} // try
	catch (e) {alert (e.message);}


function SetGrep (find, change, obj) {
	app.findGrepPreferences = app.changeGrepPreferences = null;
	try {app.findGrepPreferences.findWhat = find} catch(e) {};
	try {app.changeGrepPreferences.changeTo = change} catch(e) {};
	if (arguments.length > 0) {
	    var last = arguments[arguments.length-1];
	    last.constructor.name == "Object" ? obj = last : obj = {};
	    try {app.findGrepPreferences.appliedParagraphStyle = obj.PS} catch(e){};
	    try {app.findGrepPreferences.appliedCharacterStyle = obj.CS} catch(e){};
	    }
	else {obj = {}}
	app.findChangeGrepOptions.properties = {
	    includeFootnotes: (obj.FN == null ? false: true),
	    includeHiddenLayers: (obj.HL == null ? false: true),
	    includeLockedLayersForFind: (obj.LL == null ? false: true),
	    includeLockedStoriesForFind: (obj.LS == null ? false: true),
	    includeMasterPages: (obj.MP == null ? false: true)
	    }
	} // end set_grep