﻿//DESCRIPTION: Convert ID footnotes to stand-alone footnotes
// Peter Kahrel -- www.kahrel.plus.com

#target indesign;

try {footnotes_in_columns ()}
	catch (e) {alert (e.message + " (line " + e.line + ")")};

//-----------------------------------------------------------------------------------------------

function footnotes_in_columns (doc)
	{
	var ResetRuler = SetRuler(); //We need rulers per page
	var doc = app.activeDocument;
	var footn, first_frame, frame, fn, i;
	var styles = fix_styles (doc);
	fix_returns (doc, styles);
	// ColumnNotes is used to link footnote stories to their parent stories
	var ColumnNotes = {};
	var stories = doc.stories.everyItem().getElements();
	for (var j = 0; j < stories.length; j++)
		{
		footn = stories[j].footnotes.everyItem().getElements();
		if (footn.length > 0)
			{
			first_frame = footn[0].storyOffset.parentTextFrames[0];
			frame = place_frame (first_frame, styles);
			for (i = 0; i < footn.length; i++)
				{
				footn[i].parent.insertionPoints[footn[i].storyOffset.index+1].contents = String(footn[i].index+1)
				footn[i].texts[0].move (LocationOptions.after, frame.parentStory.insertionPoints[-1]);
				frame.parentStory.insertionPoints[-1].contents = "\r";
				} // for (i
			frame.characters[-1].remove();
			ColumnNotes[stories[j].id] = frame.parentStory.id;
			} //if (footn.length
		} // for (var j
	delete_notemarkers (doc);
	doc.insertLabel ("FootnoteStoryLinks", ColumnNotes.toSource());
	doc.insertLabel ("FootnoteObjectStyle", styles.ostyle.name);
//~ 	doc.insertLabel ("FootnoteReferenceStyle", styles.cstyle.name);
	ResetRuler();
//~ 	frame.select();
	}


function fix_returns (fn, styles)
	{
	// Find all second and further paragraphs in footnotes
	// and apply the next style non-destructively
	set_grep ("(?s)(?<=\\r).+", {PS: styles.pstyle, FN: true});
	var found = app.activeDocument.findGrep();
	for (var i = 0; i < found.length; i++)
		found[i].applyParagraphStyle (styles.next_pstyle, false);
	}



function place_frame (frame, styles)
	{
	var page;
	var gb = frame.geometricBounds;
	frame.hasOwnProperty("parentPage") ? page = frame.parentPage : page = frame.parent;
	if (page.marginPreferences.columnCount == 1) {gb[0]=gb[2]-100;}
	else
		{
		var left; page.side == PageSideOptions.rightHand ? left = page.marginPreferences.left : left = page.marginPreferences.right;
		var right = page.marginPreferences.columnsPositions.pop()+left;
		gb = [gb[2]-100, left, gb[2], right];
		}
	var NewF = page.textFrames.add ({geometricBounds: gb});
	NewF.applyObjectStyle (styles.ostyle);
	return NewF;
	}


function delete_notemarkers (scope)
	{
	app.findGrepPreferences = app.changeGrepPreferences = null;
	app.findChangeGrepOptions.includeFootnotes = true;
	app.findGrepPreferences.findWhat = '~F';
	scope.changeGrep ();
	}


function fix_styles (doc)
	{
	// Add a new style for the footnotes if they use [Basic or [No . . .]
	if (doc.footnoteOptions.footnoteTextStyle.name[0] == "["){
		if (doc.paragraphStyles.item ("footnote_text") == null){
			doc.paragraphStyles.add ({name:"footnote_text", basedOn:doc.paragraphStyles[1]});
		}
		doc.footnoteOptions.footnoteTextStyle = doc.paragraphStyles.item ("footnote_text");
	}
	with (doc.footnoteOptions.footnoteTextStyle){
		bulletsAndNumberingListType = ListType.numberedList;
		numberingExpression = "^#" + doc.footnoteOptions.separatorText;
		spaceBefore = doc.footnoteOptions.spaceBetween;
	}
	// Add a fn style for second and further paragraphs in a note
	var next_name = doc.footnoteOptions.footnoteTextStyle.name+"_nonum";
	if (!doc.paragraphStyles.item (next_name).isValid)
		{
		doc.paragraphStyles.add ({
		basedOn: doc.footnoteOptions.footnoteTextStyle,
		name: next_name, 
		bulletsAndNumberingListType: ListType.noList});
		}
	var next_style = doc.paragraphStyles.item (next_name);
	
	doc.footnoteOptions.separatorText = "";

	// Add char. style for the note references if it's currently set to [None] or (Ignore)
	if (doc.footnoteOptions.footnoteMarkerStyle == doc.characterStyles[0] || doc.footnoteOptions.footnoteMarkerStyle == null){
		if (doc.characterStyles.item("footnote_reference") == null){
			doc.characterStyles.add ({name:"footnote_reference"});
		}
		doc.footnoteOptions.footnoteMarkerStyle = doc.characterStyles.item("footnote_reference");
	}

	if (!doc.colors.item ("footnote_reference").isValid)
		{
		with (doc.footnoteOptions.footnoteMarkerStyle){
			underline=true;
			underlineWeight = "12pt";
			underlineTint = 40;
			underlineColor = doc.colors.add({name:"footnote_reference", colorValue: [0,100,0,0]});
			}
		}
	

	var n = "footnotes_columns";
	if (doc.objectStyles.item(n) == null)
		{
		with (doc.objectStyles.add({name: n}))
			{
			basedOn = doc.objectStyles[0];
			enableFill = enableStroke = enableStrokeAndCornerOptions = false;
			enableParagraphStyle = true;
				appliedParagraphStyle = doc.footnoteOptions.footnoteTextStyle;
			enableTextFrameGeneralOptions = true;
				textFramePreferences.verticalJustification = VerticalJustification.bottomAlign;
				// Try and guess how many columns are needed in the notes frame
				if (app.activeWindow.activePage.marginPreferences.columnCount > 1)
					textFramePreferences.textColumnCount = 1;
				else
					textFramePreferences.textColumnCount = 2;
			enableTextWrapAndOthers = true;
				try {/*CS4+*/textWrapPreferences.textWrapMode = TextWrapModes.nextColumnTextWrap;}
				catch (_){/*CS3*/textWrapPreferences.textWrapType = TextWrapTypes.nextColumnTextWrap;}
				textWrapPreferences.textWrapOffset = doc.footnoteOptions.spacer;
			}
		}
	return {pstyle: doc.footnoteOptions.footnoteTextStyle, 
					next_pstyle: next_style,
					cstyle: doc.footnoteOptions.footnoteMarkerStyle, 
					ostyle: doc.objectStyles.item(n)}
	} // fix_styles


function SetRuler ()
	{
	var r = app.activeDocument.viewPreferences.rulerOrigin;
	app.activeDocument.viewPreferences.rulerOrigin = RulerOrigin.pageOrigin;
	return function (){app.activeDocument.viewPreferences.rulerOrigin=r}
	}

function set_grep (find, change, obj) {
	app.findGrepPreferences = app.changeGrepPreferences = null;
	try {app.findGrepPreferences.findWhat = find} catch(_) {};
	try {app.changeGrepPreferences.changeTo = change} catch(_) {};
	if (arguments.length > 0) {
	    var last = arguments[arguments.length-1];
	    last.constructor.name == "Object" ? obj = last : obj = {};
	    try {app.findGrepPreferences.appliedParagraphStyle = obj.PS} catch(_){};
	    try {app.findGrepPreferences.appliedCharacterStyle = obj.CS} catch(_){};
	    }
	else {obj = {}}
	app.findChangeGrepOptions.properties = {
	    includeFootnotes: (obj.FN == null ? false: true),
	    includeHiddenLayers: (obj.HL == null ? false: true),
	    includeLockedLayersForFind: (obj.LL == null ? false: true),
	    includeLockedStoriesForFind: (obj.LS == null ? false: true),
	    includeMasterPages: (obj.MP == null ? false: true)
	    }
	} // end set_grep