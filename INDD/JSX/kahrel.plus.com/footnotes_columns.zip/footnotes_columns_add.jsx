﻿//DESCRIPTION: Add a new footnoteframe (CS3 and later, last tested in CS5)
// Peter Kahrel -- www.kahrel.plus.com

#target indesign;

if (app.selection.length > 0 && JustTextFrames (app.selection))
	{
	var resetRuler = setRuler(app.activeDocument); //We need rulers per page and points
	var Frames = app.selection;
	var Previous = FindPrevious (Frames[0]);
	var NewFrame = PlaceFrame (Frames[0]);
	Previous.nextTextFrame = NewFrame;
   Resize (Frames, NewFrame);
   resetRuler ();
	NewFrame.select();
	}
else {alert ("Select one or more text frames.");}


function PlaceFrame (frame)
	{
	var gb = frame.geometricBounds;
	var page = FindPage (frame);
	var leading = GetLeading (app.activeDocument.footnoteOptions.footnoteTextStyle);
	if (page.marginPreferences.columnCount == 1)
		{gb[0]=gb[2]-leading;}
	else
		{
		var left; page.side == PageSideOptions.rightHand ? left = page.marginPreferences.left : left = page.marginPreferences.right;
		var right = page.marginPreferences.columnsPositions.pop()+left;
		gb = [gb[2]-leading, left, gb[2], right];
		}
	var NewF = page.textFrames.add ({geometricBounds: gb});
	NewF.applyObjectStyle (app.activeDocument.objectStyles.item (app.activeDocument.extractLabel ("FootnoteObjectStyle")));
	return NewF;
	}


function FindPrevious (frame)
	{
	var doc = app.activeDocument;
	// The footnote story's ID can be found in a doc. label
	var LookUp = eval(doc.extractLabel ("FootnoteStoryLinks"));
	var FNstoryID = LookUp[frame.parentStory.id];
	var FNframes = doc.stories.itemByID(FNstoryID).textContainers;
	var last = FNframes[FNframes.length-1];
	// This is the easy case: the last footnote frame precedes the current page
	if (FindPage(last).documentOffset < FindPage(frame).documentOffset)
		return last;
	else
		{
		// A bit more work: find the first footnote frame after the current page
		var current = FindPage(frame).documentOffset;
		var n = 0;
		while (FindPage(FNframes[n]).documentOffset < current){++n;}
		return FNframes[--n];
		}
	}


function FindPage (frame){ // This simple version will do for this script
	if (frame.hasOwnProperty("parentPage")) {return frame.parentPage;}
	else {return frame.parent;}
	}

// ===================================================================

function Resize (TxtFrames, notes)
	{
	if (notes.contents.length > 0)
		{
		SetGrep ("^.", app.activeDocument.footnoteOptions.footnoteTextStyle);
		SetText ("", app.activeDocument.footnoteOptions.footnoteMarkerStyle);
		var leading = GetLeading (app.activeDocument.footnoteOptions.footnoteTextStyle);
		gb = notes.geometricBounds;
		var n = notes.findGrep().length;
		// Enlarge the footnote frame untill the number of notes matches 
		// the number of cues on that page
		while (n < CountCues (TxtFrames))
			{
			gb[0] -= leading;
			notes.geometricBounds = gb;
			n = notes.findGrep().length;
			} // while
		// Much of the last note may be overset. Therefore now try 
		// to get as much of the note into the frame
		while (n == notes.findGrep().length && notes.paragraphs[-1].lines[-1].parentTextFrames[0]==null)
			{
			gb[0] -= leading;
			notes.geometricBounds = gb;
			} // while
		} // if (notes
	} // Resize


function CountCues (selected_frames)
	{
	var sum = 0;
	for (var i = 0; i < selected_frames.length; i++)
		sum += selected_frames[i].findText().length;
	return sum;
	}


function SetGrep (find, pstyle){
	app.findGrepPreferences = null; app.findGrepPreferences.findWhat = find;
	app.findGrepPreferences.appliedParagraphStyle = pstyle;
} // setupFindGrep


function SetText (find, cstyle){
    app.findTextPreferences = null; app.findTextPreferences.findWhat = find;
    app.findTextPreferences.appliedCharacterStyle = cstyle;
} // setupFindText


function GetLeading (p){
	if (p.leading == Leading.auto) {return (p.pointSize * p.autoLeading) / 100;}
	else {return p.leading;}
}


function JustTextFrames (sel){
	var temp = true;
	for (var i = 0; i < sel.length; i++){
		if (sel[i].constructor.name != "TextFrame") {temp = false;}
	}
	return temp;
}


function setRuler (doc){
	var viewPrefs = doc.viewPreferences.properties;
	doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.points;
	doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.points;
	doc.viewPreferences.rulerOrigin = RulerOrigin.pageOrigin;
	doc.zeroPoint = [0,0];
	return function () {doc.viewPreferences.properties = viewPrefs;}
}
