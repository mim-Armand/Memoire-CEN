﻿#target indesign;

obj_style = "sidenote";

app.findObjectPreferences = null;
app.findObjectPreferences.appliedObjectStyles = app.documents[0].objectStyles.item(obj_style);
var f = app.documents[0].findObject();
for (var i = 0; i < f.length; i++)
    f[i].fit(FitOptions.frameToContent);