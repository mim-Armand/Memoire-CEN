﻿
#target indesign;

doc = app.documents[0];

//~ app.findGrepPreferences = app.changeGrepPreferences = null;
//~ app.findGrepPreferences.findWhat = "(?<=~a)\\d+";
//~ app.documents[0].findGrep().length;


//~ app.documents[0].paragraphDestinations.everyItem().remove();
//~ app.documents[0].crossReferenceSources.everyItem().remove();
//~ app.documents[0].hyperlinks.everyItem().remove();

//~ exit ();

//~ t.parent.parent.insertionPoints.item (t.parent.index+1)

story = app.selection[0].parentStory;

cr_format = doc.crossReferenceFormats.item ("sidenote");

app.findGrepPreferences = app.changeGrepPreferences = null;
app.findGrepPreferences.appliedParagraphStyle = doc.paragraphStyles.item ("note_numbered");
n = doc.findGrep(true);
for (i = 0; i < n.length; i++)
	{
	endnote_link = doc.paragraphDestinations.add (n[i].insertionPoints[0]);
	ip = story.insertionPoints.item (n[i].parentTextFrames[0].parent.index+1);
	reference = doc.crossReferenceSources.add (ip, cr_format);
	doc.hyperlinks.add (reference, endnote_link, {visible: false});
//~ 	doc.crossReferenceSources.everyItem().update();
	}