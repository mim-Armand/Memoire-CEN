﻿//DESCRIPTION: Restart numbering sidenotes on every section, spread, or page
// Peter Kahrel - www.kahrel.plus.com

//#target indesign


if (parseInt (app.version) > 5 && app.documents.length > 0)
    try {renumber_notes (app.documents[0], "sidenote")}
        catch (e) {alert (e.message + " (line " + e.line + ")")};
		

function renumber_notes (doc, o_style)
	{
	var mode = renumber_mode (doc);
	reset_numbers (doc, o_style);
	switch (mode)
		{
		case 'None': break;
		case 'Page': renumber_each_page (doc, o_style); break;
		case 'Spread': renumber_each_spread (doc, o_style); break;
		case 'Section': renumber_each_section (doc, o_style); break;
		}
	doc.crossReferenceSources.everyItem().update();
	}


function renumber_each_section (doc, o_style){
	var notes = findNotes (doc, o_style);
	var sectionIndex = 0;
	for (var i = 0; i < notes.length; i++){
		if (notes[i].parent.parentTextFrames[0].parentPage.appliedSection.index > sectionIndex){
			notes[i].paragraphs[0].numberingContinue = false;
			sectionIndex = notes[i].parent.parentTextFrames[0].parentPage.appliedSection.index;
		}
	}
}


function renumber_each_spread (doc, o_style) {
	var notes = findNotes (doc, o_style);
	var spreadIndex = 0;
	for (var i = 0; i < notes.length; i++){
		if (notes[i].parent.parentTextFrames[0].parentPage.parent.index > spreadIndex){
			notes[i].paragraphs[0].numberingContinue = false;
			spreadIndex++
		}
	}
}


function renumber_each_page (doc, o_style) {
	var notes = findNotes (doc, o_style);
	var pageIndex = 0;
	for (var i = 0; i < notes.length; i++){
		if (notes[i].parent.parentTextFrames[0].parentPage.documentOffset > pageIndex){
			notes[i].paragraphs[0].numberingContinue = false;
			pageIndex++
		}
	}
}


function findNotes (doc, o_style) {
	app.findObjectPreferences = null;
	app.findObjectPreferences.appliedObjectStyles = doc.objectStyles.item (o_style);
	return doc.findObject();
}


function reset_numbers (doc, o_style) {
	// Start numbering from the beginning of the document
	var notes = findNotes (doc, o_style);
	for (var i = 0; i < notes.length; i++) {
		notes[i].paragraphs[0].numberingContinue = true;
	}
}


function renumber_mode (doc)
	{
	var w = new Window ('dialog', "Sidenote options", undefined, {closeButton: false});
		w.alignChildren = "right";
		var panel = w.add ('panel {orientation: "row"}');
			var prompt = panel.add ('checkbox', undefined, '\u00A0Restart numbering every');
			var list = panel.add ('dropdownlist', undefined, ['Page', 'Spread', 'Section']);
				list.preferredSize.width = 100;
		var buttons = w.add ('group');
			buttons.add ('button', undefined, 'OK', {name: 'ok'});
			buttons.add ('button', undefined, 'Cancel', {name: 'cancel'});


	var sidenote_restarting = doc.extractLabel ('sidenote_restarting');
	if (sidenote_restarting != "")
		{
		prompt.value = true;
		switch (sidenote_restarting)
			{
			case 'None': list.selection = 0; list.enabled = false; prompt.value = false; break;
			case 'Page': list.selection = 0; break;
			case 'Spread': list.selection = 1; break;
			case 'Section': list.selection = 2; break;
			}
		}
	else
		{
		list.selection = 0;
		list.enabled = false;
		}
	
	prompt.onClick = function () {list.enabled = this.value}

	if (w.show() == 1)
		{
		if (prompt.value)
			{
			doc.insertLabel ('sidenote_restarting', list.selection.text);
			return list.selection.text;
			}
		else
			{
			doc.insertLabel ('sidenote_restarting', 'None');
			return 'None';
			}
		}
	else
		exit();
	}// renumber_mode