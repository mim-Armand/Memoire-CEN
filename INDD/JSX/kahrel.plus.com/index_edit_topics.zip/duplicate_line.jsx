//DESCRIPTION: Duplicate selected paragraphs

if (parseInt (app.version) > 4 && app.documents.length > 0 && app.selection.length > 0)
	try {duplicate_paragraphs (app.selection[0].paragraphs)} catch (_){};


function duplicate_paragraphs (coll)
	{
	for (var i = coll.length-1; i > -1; i--)
		{
		if (coll[i].characters[-1].contents == "\r")
			x = -2;
		else
			x = -1;
		coll[i].insertionPoints[x].contents = "\t" + coll[i].contents.replace (/\r$/, "");
		}
	}