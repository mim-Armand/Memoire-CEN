﻿//DESCRIPTION: List index topics

#target indesign

// CS3 or later
if (parseInt (app.version) > 4 && app.documents.length > 0 && app.documents[0].indexes.length > 0)
	{
	app.scriptPreferences.enableRedraw = false;
	var path = app.documents[0].filePath;
	if (File (path + "/index_update.indd").exists)
		errorM (path + "/index_update.indd already exists.\rPlease rename or remove it.")
	message_txt = create_message (30, 'Show index');
	var refs = find_references (app.documents[0]);
	index_list = print_refs (refs);
	message_dlg.close ();
	try {app.documents[0].save (File (path + "/index_update.indd"))}
		catch (e) {alert (e.message)}
	}


// This function lists all topics that have page references
function find_references (doc)
	{
	message_txt.text = "Collecting topics...";
	var doc_topics = doc.indexes[0].allTopics;
	var array = [];
	for (var i = 0; i < doc_topics.length; i++)
		{
		try
			{
			message_txt.text = doc_topics[i].name;
			if (doc_topics[i].pageReferences.length > 0)
				array.push (topic_path (doc_topics[i], doc_topics[i].name));
			}
		catch (_){}
		}
	return array;
	}


// Create topic string. Subtopics are separated by '#'
function topic_path (top, str)
	{
	if (top.parent.constructor.name == 'Index')
		return str;
	else
		return topic_path (top.parent, top.parent.name + '#' + str)
	}


function print_refs (array)
	{
	message_txt.text = "Writing entries in new document...";
	var doc = app.documents.add ();
	var gbounds = page_bounds (doc);
	try {app.documents[0].paragraphStyles[1].tabList = [{position: "140pt", alignment: TabStopAlignment.leftAlign}]} catch(_){};
	doc.pages[0].textFrames.add ({geometricBounds: gbounds, contents: array.join ("\r")});
	add_pages (doc, gbounds);
	return doc;
	}


function page_bounds (doc)
	{
	var m = doc.pages[0].marginPreferences;
	return [m.top, m.left, 
		doc.documentPreferences.pageHeight - m.bottom, 
		doc.documentPreferences.pageWidth - m.right];
	}


function add_pages (doc, gb)
	{
	message_txt.text = 'Adding pages...';
	doc.viewPreferences.rulerOrigin = RulerOrigin.pageOrigin;
	var n = 1;
	while (doc.pages[-1].textFrames[0].overflows)
		{
		message_txt.text = 'Adding pages...' + String (n++);
		doc.pages.add ().textFrames.add ({geometricBounds: gb});
		doc.pages[-1].textFrames[0].previousTextFrame = doc.pages[-2].textFrames[0];
		}
	doc.layoutWindows[0].activePage = doc.pages[0];
	}


function create_message (le, title)
	{
	message_dlg = new Window('palette', title);
	message_dlg.alignChildren = ['left', 'top'];
	var message_txt = message_dlg.add('statictext', undefined, '');
	message_txt.characters = le;
	message_dlg.show();
	return message_txt;
	}


function errorM (m)
	{
	alert (m);
	exit ()
	}
