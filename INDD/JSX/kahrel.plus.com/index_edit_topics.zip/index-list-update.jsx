﻿//DESCRIPTION: Update index from list
// Peter Kahrel -- www.kahrel.plus.com

/*
	The script runs only when there are two documents open:
	1. The document with the index to be updated; the document can have any name.
	2. A document with the update list. This document's name must be index_update.indd.
	It doesn't matter which documant is the active one
*/

//==============================================================================

if (parseInt (app.version) > 4 && app.documents.length != 2)
	errorM ("Open (just) two documents: the text and index_update.indd.");
update_index ();

//===============================================================================

function update_index (doc)
	{
	var updater = find_updater ("index_update.indd");
	var doc = find_text ();
	mess = create_message (40, 'Updating index');
	var list = get_list (updater);
	update_topics (doc, list);
	message_dlg.close ();
	}


function update_topics (doc, array)
	{
	var old_topic; var new_topic; var reftype; var newref;
	var errorstring = "";
	var index = doc.indexes[0];
	index.update ();  // update the preview
	for (var i = 0; i < array.length; i++)
		{
		var temp = array[i].split ("\t");
		if (temp.length > 1)  // i.e. if the line contains a tab
			{
			try
				{
				old_topic = chain_intopics (index, temp[0]);
				if (old_topic == null)
					errorstring += temp[0] + " is not a topic.\r";
				else
					{
					mess.text = temp[0] + " > " + temp[1];
					new_topic = add_topic (index, temp[1]);
					for (var j = old_topic.pageReferences.length-1; j > -1; j--)
						{
						reftype = old_topic.pageReferences[j].pageReferenceType;
						newref = new_topic.pageReferences.add (old_topic.pageReferences[j].sourceText, reftype);
						// Set "For next # of pages/paragraphs"
						if (reftype == PageReferenceType.forNextNPages || reftype == PageReferenceType.forNextNParagraphs)
							newref.pageReferenceLimit = old_topic.pageReferences[j].pageReferenceLimit;
						old_topic.pageReferences[j].remove();
						}
					}
				}
			catch (_) {errorstring += "Problem with " + temp[0] + "\r"}
			}
		}
	index.update ();  // update the preview again
	log_errors (errorstring);
	}


function log_errors (s)
	{
	var f = File (app.documents[0].filePath + "/index_update_errors.txt");
	f.open ("w"); f.encoding = 'UTF-8';
	if (s == "")
		f.write ("No errors.");
	else
		f.write (s);
	f.close ();
	f.execute();
	}


function chain_intopics (index, s)
	{
	var array = s.split ("#");
	switch (array.length)
		{
		case 4: return index.topics.item(array[0]).topics.item(array[1]).topics.item(array[2]).topics.item(array[3]);
		case 3: return index.topics.item(array[0]).topics.item(array[1]).topics.item(array[2]);
		case 2: return index.topics.item(array[0]).topics.item(array[1]);
		case 1: return index.topics.item(array[0]);
		}
	}


// Create a new topic
function add_topic (index, s)
	{
	var array = s.split ("#");
	var t = index.topics.add (array[0]);
	for (var i = 1; i < 4; i++)
		if (array[i] != undefined)
			t = t.topics.add (array[i]);
	return t
	}


function get_list (doc)
	{
	try {return doc.stories[0].contents.split ("\r")}
		catch (e) {alert (e.message); exit ()}
	}


//~ function get_list (path, s)
//~ 	{
//~ 	if (File (path + "/" + s).exists == false)
//~ 		{
//~ 		var f = path.openDlg ("Select list", "InDesign file:*.indd", false);
//~ 		if (f == null)
//~ 			exit ();
//~ 		}
//~ 	else
//~ 		{
//~ 		f = File (path + "/" + s);
//~ 		}
//~ 	app.scriptPreferences.userInteractionLevel = UserInteractionLevels.neverInteract;
//~ 	app.open (f);
//~ 	app.scriptPreferences.userInteractionLevel = UserInteractionLevels.interactWithAll;
//~ 	mess.text = "Reading list...";
//~ 	try
//~ 		{
//~ 		var array = app.documents[0].stories[0].contents.split ("\r");
//~ 		app.documents[0].close (SaveOptions.no);
//~ 		return array
//~ 		}
//~ 	catch (e) {alert (e.message); exit ()}
//~ 	}


function find_updater (s)
	{
	if (app.documents.item (s) != null)
		return app.documents.item (s);
	else
		errorM ("Can't find " + s + ".")
	}


function find_text ()
	{
	for (var i = 0; i < app.documents.length; i++)
		if (app.documents[i].indexes.length > 0)
			return app.documents[i];
	errorM ("Document doesn't have an index.");
	}


function create_message (le, title)
	{
	message_dlg = new Window('palette', title);
	message_dlg.alignChildren = ['left', 'top'];
	var message_txt = message_dlg.add('statictext', undefined, '');
	message_txt.characters = le;
	message_dlg.show();
	return message_txt;
	}


function errorM (m)
	{
	alert (m, "Error", true);
	exit ();
	}