﻿//DESCRIPTION: Syntax highlighting in GREP expressions
// Peter Kahrel -- www.kahrel.plus.com

#target indesign

if (parseInt (app.version) == 5)
	{
	app.findGrepPreferences = app.changeGrepPreferences = null;
	apply ("blue-light", "(?<!\\\\)[\\[\\]|?+*]");
	apply ("green", "\\(\\?-?[=!:i#xms]");
	apply ("green", "\\(\\?<[=!]");
	apply ("green", "(?<!\\\\)[(){}]");
	apply ("black", "(?<!\\\\)\\[.+?[^\\\\]\\]");
	apply ("blue-light", "(?<!\\\\)[\\[\\]]");
	apply ("red", "\\\\[\\w\\.]");
	apply ("orange", "\\\\[xp]\\{.+?\\}");
	apply ("orange", "(?<!\\\\)\\~.");
	apply ("orange", "\\[?\\[([=:]).+?\\1\\]\\]?");
	apply ("comments", "//.+");
	}


function apply (style, grep)
	{
	app.findGrepPreferences.findWhat = grep;
	app.changeGrepPreferences.appliedCharacterStyle = 
		app.documents[0].characterStyles.item (style);
	app.documents[0].changeGrep()
	}