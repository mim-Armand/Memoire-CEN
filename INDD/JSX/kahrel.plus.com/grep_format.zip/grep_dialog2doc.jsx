﻿#target indesign;

if (app.documents.length > 0)
	app.documents[0].textFrames.add (
		{geometricBounds: ["12.7mm", "12.7mm", "284.3mm", "197.3mm"],
		contents: app.findGrepPreferences.findWhat});