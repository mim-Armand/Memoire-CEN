﻿//DESCRIPTION: create GREP string for Find/Change
// Peter Kahrel -- www.kahrel.plus.com

format_grep ();

function format_grep ()
	{
	app.findGrepPreferences = app.changeGrepPreferences = null;
	replace ("//.*", "");
	replace ("\\s+", "");
	replace ("\\", "\\");
	try {app.findGrepPreferences.findWhat = app.documents[0].stories[0].contents}
	catch (e) {alert (e.message)}
	}

function replace (f, r)
	{
	app.findGrepPreferences.findWhat = f;
	app.changeGrepPreferences.changeTo = r;
	app.documents[0].changeGrep ()
	}